<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IIT Dharwad Contact Directory</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/1.jpg">
       <!-- <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">-->

    </head>
    <body>
       <style>
        .container-fluid {

  }
        .bg-1 { 
            width: 72%;
      background-color: #ffffff/*#1abc9c*/; /* Green */
      color: #071228;
      border-radius: 25px;
      padding-top: 0px;
      padding-bottom: 0px;

  }
        </style>

<?php
if ($_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro0.0.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro2.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro3.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro5.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro8.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/signup1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro4.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro6.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro9.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro10.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/signup2.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/promod.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/prochange.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro8.5.php') {
    if(isset($_POST["submit"]))
    {
        require("signup.php");
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) 
            {
                 die("Connection failed: " . mysqli_connect_error());
            }
        $tab1="details";
        $username=$_POST["username"];
        $password=$_POST["password"];
        $find="SELECT password FROM details WHERE username ='$username'";
        $temp=mysqli_query($conn, $find);
        $check = mysqli_fetch_assoc($temp);
        if(($username=="admin" && $password=="iamking") /*($password==$check["password"])*/&&($username!=""&&$password!=""))
            {
                require("login.php");
                 $conn = mysqli_connect($servername, $username, $password, $dbname);
                if (!$conn) 
                    {
                        die("Connection failed: " . mysqli_connect_error());
                    }
             echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
              echo '<form enctype="multipart/form-data" action="pro0.php" method="POST">';
    echo '<input type="submit" class="btn" value="Logout" name="back" style="float: right; width: 8%; margin-right: 2%;margin-top: 1%;background-color: #b6fb37;color: #000000f" >';
    echo '</form>';
    echo'<div class="top-content" style="margin-top: 3%">
            <div class="inner-bg">
                <img src="1.jpg" class="img-responsive img-circle
                    margin" style="display:inline;border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #90f056;" width="150" height="150">
                <div class="container">
                    <div class="row">
                        
                        <div class="container-fluid bg-1 text-center" style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37; background-color: #ffffff">
                            <h1>
                                <strong>IIT Dharwad Contact Directory</strong> 
                            </h1>
                        </div>
                    </div>';
                        echo'<div class="row " style="margin-top: 5%" >';
            echo '<form enctype="multipart/form-data" action="pro2.php" method="POST">';
                echo '<input type="submit" class="btn" value="View All Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<form enctype="multipart/form-data" action="pro3.php" method="POST">';
                echo '<input type="submit" class="btn" value="Add to Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<form enctype="multipart/form-data" action="pro5.php" method="POST">';
                echo '<input type="submit" class="btn" value="Delete Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<br>';
                echo '<form enctype="multipart/form-data" action="pro8.php" method="POST">';
                echo '<input type="submit" class="btn" value="Search Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
            echo '<br>';
            echo '<form enctype="multipart/form-data" action="promod.php" method="POST">';
                echo '<input type="submit" class="btn" value="Modify Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
            echo '<br>';
            echo '<form enctype="multipart/form-data" action="signup1.php" method="POST">';
            echo '<input type="submit" class="btn" value="Add Users" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '</p>';
                echo '</center>';
            echo '</div>';
                }

        else
            {
                echo "<script>
                alert('Login unsuccessful!');
                window.location.href='pro0.0.php';
                </script>";
            }

    }
    else 
    {
        require("login.php");
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) 
            {
                die("Connection failed: " . mysqli_connect_error());
            }
             echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
              echo '<form enctype="multipart/form-data" action="pro0.0.php" method="POST">';
    echo '<input type="submit" class="btn" value="Logout" name="back" style="float: right; width: 8%; margin-right: 2%;margin-top: 0%;background-color: #b6fb37;color: #000000" >';
    echo '</form>';
    echo'<div class="top-content" style="margin-top: 3%">
            <div class="inner-bg">
                <img src="1.jpg" class="img-responsive img-circle
                    margin" style="display:inline;border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #90f056;" width="150" height="150">
                <div class="container">
                    <div class="row">
                        
                        <div class="container-fluid bg-1 text-center" style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #90f056; background-color: #ffffff">
                            <h1>
                                <strong>IIT Dharwad Contact Directory</strong> 
                            </h1>
                        </div>
                    </div>';
                        echo'<div class="row " style="margin-top: 5%" >';
            echo '<form enctype="multipart/form-data" action="pro2.php" method="POST">';
                echo '<input type="submit" class="btn" value="View All Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<form enctype="multipart/form-data" action="pro3.php" method="POST">';
                echo '<input type="submit" class="btn" value="Add to Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<form enctype="multipart/form-data" action="pro5.php" method="POST">';
                echo '<input type="submit" class="btn" value="Delete Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<br>';
                echo '<form enctype="multipart/form-data" action="pro8.php" method="POST">';
                echo '<input type="submit" class="btn" value="Search Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
            echo '<br>';
            echo '<form enctype="multipart/form-data" action="promod.php" method="POST">';
                echo '<input type="submit" class="btn" value="Modify Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
            echo '<br>';
            echo '<form enctype="multipart/form-data" action="signup1.php" method="POST">';
            echo '<input type="submit" class="btn" value="Add Users" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" >';
                echo '</form>';
                echo '</p>';
                echo '</center>';
            echo '</div>';
    }
}
else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>
</body>
 <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
</html>