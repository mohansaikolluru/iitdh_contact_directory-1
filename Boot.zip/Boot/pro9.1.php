<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IIT Dharwad Contact Directory</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/1.jpg">
       <!-- <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">-->

    </head>

    <body>
        <style>
        .container-fluid {

  }
        .bg-1 { 
            width: 72%;
      background-color: #ffffff/*#1abc9c*/; /* Green */
      color: #071228;
      border-radius: 25px;
      padding-top: 0px;
      padding-bottom: 0px;

  }
        </style>

<?php
if ($_SERVER['HTTP_REFERER'] == 'http://localhost/Boot/pro8.1.php'){
echo '<form enctype="multipart/form-data" action="pro1.0.php" method="POST">
               <input type="submit" class="btn" value="Back" name="back" style="float: left; width: 6%; margin-left: 2%;margin-top: 1%;background-color: #b6fb37;color: #000000" >
                </form>';
echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
echo'<div class="top-content">
            <div class="inner-bg">
                <img src="1.jpg" class="img-responsive img-circle
                    margin" style="display:inline;border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;" width="150" height="150">
                <div class="container">
                    <div class="row">
                        
                        <div class="container-fluid bg-1 text-center" style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37; background-color: #ffffff">
                            <h1>
                                <strong>IIT Dharwad Contact Directory</strong> 
                            </h1>
                        </div>
                    </div>
                    <br>
                    <br>';

/*$servername = "localhost/Boot";
$username = "root";
$password = "password";
$dbname = "publications";*/
require("login.php");
///edit input variables om lines 16 to 18 according to the form...
/////////////table 1
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//$tab1="authors"; $tab1r1="name";$tab1r2="email";$tab1r1="country";
//$tab2="titles"; $tab2r1="name";$tab2r2="title";$tab1r1="year";
//$name=$_POST["name"];
$department=$_POST["department"];
//$title='%$titley%';//uncomment this!
//$title='sherlock holmes';//$_POST["title"];
//$year=$_POST["year"];
//$rev_year=$_POST["rev_year"];
//$update="'$name': SELECT * FROM 'titles' WHERE 'name' LIKE '%'$name'%'";
//$sel = "SELECT $name,$year FROM titles";
    //$add="UPDATE $tab2 SET year = $rev_year WHERE year = $year AND name = '$name'";
if($department!="")
{
$find="SELECT * FROM professor WHERE department LIKE '%$department%'";
//$sql = "SELECT name,department,email,numero FROM professor";
$result = mysqli_query($conn, $find);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    //echo "<center>";
    echo'<div class="container" >
    <table class="table">
    <thead>
      <tr class="info">
        <th>Name</th>
        <th>Department</th>
        <th>Designation</th>
        <th>Email</th>
        <th>Number</th>
      </tr>
    </thead>
    <tbody>';
    
   while($row = mysqli_fetch_assoc($result)) {
    echo'<tr class="warning">';
        echo'<td style="text-align:left"><strong>'.$row["name"].'</td>
        <td style="text-align:left"><strong>'.$row["department"].'</td>
        <td style="text-align:left"><strong>'.$row["designation"].'</td>
        <td style="text-align:left"><strong>'.$row["email"].'</td>
       <td style="text-align:left"><strong>'.$row["numero"].'</td>
      </tr>';
       /* echo "<b>"."Name:"."</b>" ."        ". $row["name"]."<br>". "<b>"."Department:"."</b>"."        ". $row["department"]."<br>". "<b>"."Designation:"."</b>"."      ". $row["designation"]."<br>". "<b>"."Email:"."</b>" ."        ". $row["email"]. "<br>". "<b>"."Number:"."</b>" ."        ". $row["numero"]. "<br>"."------------------------------------------------------------------------"."<br>";*/
    }echo'
    </tbody>
  </table>
</div>';

} else {
    //echo "0 results";
     echo "<script>
                alert('No such record found!');
                window.location.href='pro8.1.php';
                </script>";

}
}
else{
echo "<script>
                alert('Details not provided!');
                window.location.href='pro8.1.php';
                </script>";
            }

//echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"."<br>"."<br>";
mysqli_close($conn);
echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
//echo '<button class="btn"><i class="fa fa-home"></i> Home</button>';
//else echo "Oops! No such record found!";

//$add;
/*if (mysqli_query($conn, $add) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}*/
//$sql = "SELECT name,title,year FROM titles";
//$result = mysqli_query($conn, $sql);

/*if (mysqli_num_rows($result) > 0) {
    // output data of each row
    //echo "<center>";
    echo " <b>";
    echo "Titles";
    //echo "</center>";
    echo " </b>"."<br>"."<br>";
    
    while($row = mysqli_fetch_assoc($result)) {
        echo "<b>"."Name:"."</b>" ."		". $row["name"]."<br>". "<b>"."Title:"."</b>"."		". $row["title"]."<br>". "<b>"."Year:"."</b>" ."		". $row["year"]. "<br>"."-------------------------"."<br>";
    }
} else {
    echo "0 results";

}
echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"."<br>"."<br>";*/
}else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>
</body>
 <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
</html>