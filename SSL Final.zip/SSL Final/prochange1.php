<?php
if ($_SERVER['HTTP_REFERER'] == 'http://localhost/promod1.php')
{
echo '<title>IIT Dharwad Contact Directory</title>';
echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
echo '<form enctype="multipart/form-data" action="pro1.0.php" method="POST">
 <button type="submit" style="font-size : 15px; width: 7%; height: 25px;"class="btn"><i class="fa fa-home"></i> Home</button>
</form>';
/*$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "publications";*/
require("login.php");
///edit input variables om lines 16 to 18 according to the form...
/////////////table 1
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$tab1="professor";// $tab1r1="name";$tab1r2="department";$tab1r1="email";
//$tab2="titles"; $tab2r1="name";$tab2r2="title";$tab1r1="year";
$name=$_POST["name"];
//echo $name;
$email=$_POST["email"];
//echo $email;
$department=$_POST["department"];
//echo $department;
$number=$_POST["numero"];
//echo $number;
$namec=$_POST["namec"];
//echo $namec;
$emailc=$_POST["emailc"];
//echo $emailc;
$departmentc=$_POST["departmentc"];
//echo $departmentc;
$numberc=$_POST["numeroc"];
//echo $numberc;
$designationc=$_POST["designationc"];
//echo $designationc;
$phone = $number;
//echo $phone;
$phonec = $numberc;
//echo $phonec;

if($name!=""&&$email!=""&&$department!=""&&$number!="")//&&$namec!=""&&$emailc!=""&&$departmentc!=""&&$numberc!=""&&$departmentc!="")
{
	if(preg_match("/^\+91-[2,7,8,9][0-9]{9}$/", $phone)||preg_match("/^\+91-836[0-9]{7}$/", $phone)||preg_match("/^NA$/", $phone))//||preg_match("/^\+91-[2,7,8,9][0-9]{9}$/", $phonec)||preg_match("/^\+91-836[0-9]{7}$/", $phonec)||preg_match("/^NA$/", $phonec)) 
        	{
           
            	$find="SELECT * FROM professor WHERE name= '$name' AND department='$department' AND email='$email'AND numero='$number'";
            	$temp=mysqli_query($conn, $find);
            	$check = mysqli_fetch_assoc($temp);
            	if($check["name"]!=$name&&$check["department"]!=$department&&$check["email"]!=$email&&$check["numero"]!=$number)
                	{
                    	echo "<script>
                    	alert('Record not found! Kindly re-check your details');
                    	window.location.href='promod1.php';
                    	</script>";
        	
                	}	 
                else
                	{
                		if($namec!=""&&$emailc!=""&&$departmentc!=""&&$numberc!=""&&$designationc!="")
                			{
                				if(preg_match("/^\+91-[2,7,8,9][0-9]{9}$/", $phonec)||preg_match("/^\+91-836[0-9]{7}$/", $phonec)||preg_match("/^NA$/", $phonec))
                					{
                						$query = "DELETE FROM professor WHERE name= '$name' AND department='$department' AND email='$email'AND numero='$number'";
                        				mysqli_query($conn, $query);
                        				$add="INSERT INTO professor (name,department,email,numero,designation) VALUES ('$namec', '$departmentc','$emailc','$numberc','$designationc')"; 
                        				 mysqli_query($conn, $add);
                        				 $sql = "SELECT name,department,email,numero,designation FROM professor";
                        				 $result = mysqli_query($conn, $sql);
                        				 if (mysqli_num_rows($result) > 0) 
                            				{
                                				echo " <b>";
                                				echo "Records";
                                				echo " </b>"."<br>"."<br>";
                                				while($row = mysqli_fetch_assoc($result)) 
                                    				{
                                        				echo "<b>"."Name:"."</b>" ."        ". $row["name"]."<br>". "<b>"."Department:"."</b>"."        ". $row["department"]."<br>". "<b>". "Designation:"."</b>"."        ". $row["designation"]."<br>". "<b>"."Email:"."</b>" ."      ". $row["email"]. "<br>". "<b>"."Number:"."</b>" ."        ". $row["numero"]. "<br>"."---------------------------------------------------------------"."<br>";
                                    				}

                            				}
                            			else 
                                			{
                                    			echo "0 results";
                               				}
                					}
                				else 
                					{
                						echo "<script>
            							alert('Invalid new number!');
            							window.location.href='promod1.php';
            							</script>";	
                					}
                			}
                		else 
                			{
                				echo "<script>
    							alert('Provided new details are incomplete!');
    							window.location.href='promod1.php';
    							</script>";
                			}
                					
                	}
        	}
        
    else 

        {
            echo "<script>
            alert('Invalid existing number!');
            window.location.href='promod1.php';
            </script>";
        }

}
else
{
    echo "<script>
    alert('Provided existing details are incomplete!');
    window.location.href='promod1.php';
    </script>";
}
          
//echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"."<br>"."<br>";
mysqli_close($conn);
    echo '<style>
body {
    background-color: linen;
}

h1 {
    color: maroon;
    margin-left: 40px;
}';
}

else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>