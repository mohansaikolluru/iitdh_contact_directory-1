<?php
echo '<title>IIT Dharwad Contact Directory</title>';
echo '<form enctype="multipart/form-data" action="pro1.php" method="POST">
 <button type="submit" style="font-size : 15px; width: 7%; height: 25px;"class="btn"><i class="fa fa-home"></i> Home</button>
</form>';
echo '<font size="4">';
/*$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "publications";*/
require("login.php");
/////////////table 1
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT name,department,email,numero FROM professor";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
    // output data of each row
    //echo "<center>";
    echo " <b>";
    //echo "Records";
    //echo "</center>";
    echo " </b>"."<br>"."<br>";
    
    while($row = mysqli_fetch_assoc($result)) {
        echo "<b>"."Name:"."</b>" ."		". $row["name"]."<br>". "<b>"."Department:"."</b>"."		". $row["department"]."<br>". "<b>"."Email:"."</b>" ."		". $row["email"]. "<br>". "<b>"."Number:"."</b>" ."        ". $row["numero"]. "<br>"."------------------------------------------------------------------------"."<br>";
    }
} else {
    //echo "0 results";
     echo "<script>
                alert('No records available!');
                window.location.href='pro1.php';
                </script>";

}
//echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"."<br>"."<br>";
mysqli_close($conn);
echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
//echo '<button class="btn"><i class="fa fa-home"></i> Home</button>';

    echo '<style>
body {
    background-color: linen;
}

h1 {
    color: maroon;
    margin-left: 40px;
}';
/////////////table 2
/*
$conn1 = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn1) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql1 = "SELECT name,title,year FROM titles";
$result1 = mysqli_query($conn1, $sql1);

if (mysqli_num_rows($result1) > 0) {
    // output data of each row
     //echo "<center>";
    echo " <b>";
    echo "Titles";
    //echo "</center>";
    echo " </b>"."<br>"."<br>";
    
    while($row = mysqli_fetch_assoc($result1)) {
        echo "<b>"."Name:"."</b>" ."		". $row["name"]."<br>". "<b>"."Title:"."</b>"."		". $row["title"]."<br>". "<b>"."Year:"."</b>" ."		". $row["year"]. "<br>"."-------------------------"."<br>";
    }
} else {
    echo "0 results";
}
echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx";
mysqli_close($conn1);*/
?>