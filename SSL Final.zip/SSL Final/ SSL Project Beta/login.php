<?php
$servername = "localhost";
$username = "root";
$password = "password";
$create = "CREATE DATABASE records";
$conn = mysqli_connect($servername, $username, $password);
mysqli_query($conn, $create);
/*if (mysqli_query($conn, $create)) {
    echo "Database created successfully with the name newDB";
}*/
mysqli_query($conn,"USE records");
$table='CREATE TABLE professor (name VARCHAR(120), department VARCHAR(120), email VARCHAR (120), numero VARCHAR(120))';
mysqli_query($conn,$table);
/*if (mysqli_query($conn,$table))
echo "hi"; 
else echo "bye" ;*/
$dbname = "records";
?>