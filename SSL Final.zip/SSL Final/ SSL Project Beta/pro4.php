<?php
echo '<title>IIT Dharwad Contact Directory</title>';
echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
echo '<form enctype="multipart/form-data" action="pro1.php" method="POST">
 <button type="submit" style="font-size : 15px; width: 7%; height: 25px;"class="btn"><i class="fa fa-home"></i> Home</button>
</form>';
/*$servername = "localhost";
$username = "root";
$password = "password";
$dbname = "publications";*/
require("login.php");
///edit input variables om lines 16 to 18 according to the form...
/////////////table 1
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$tab1="professor";// $tab1r1="name";$tab1r2="department";$tab1r1="email";
//$tab2="titles"; $tab2r1="name";$tab2r2="title";$tab1r1="year";
$name=$_POST["name"];
$email=$_POST["email"];
$department=$_POST["department"];
$number=$_POST["numero"];
$phone = $number;


if($name!=""&&$email!=""&&$department!=""&&$number!="")
{

    if(preg_match("/^\+91-[7,8,9][0-9]{9}$/", $phone)||preg_match("/^\+91-0836[0-9]{6}$/", $phone)) 
        {
            $add="INSERT INTO $tab1 (name,department,email,numero) VALUES ('$name', '$department','$email','$number')"; 
            mysqli_query($conn, $add);
            $sql = "SELECT name,department,email,numero FROM professor";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) 
                {
                    echo " <b>";
                    echo "Records";
                    echo " </b>"."<br>"."<br>";
                    while($row = mysqli_fetch_assoc($result)) 
                        {
                            echo "<b>"."Name:"."</b>" ."        ". $row["name"]."<br>". "<b>"."Department:"."</b>"."        ". $row["department"]."<br>". "<b>"."Email:"."</b>" ."      ". $row["email"]. "<br>". "<b>"."Number:"."</b>" ."        ". $row["numero"]. "<br>"."-------------------------"."<br>";
                        }
                }
            else 
                {
                    echo "0 results";

                }
        }
    else 
        {
            echo "<script>
            alert('Invalid number!');
            window.location.href='pro3.php';
            </script>";
        }

}
else
{
    echo "<script>
    alert('Provided details are incomplete!');
    window.location.href='pro3.php';
    </script>";
}
           
//echo "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"."<br>"."<br>";
mysqli_close($conn);
    echo '<style>
body {
    background-color: linen;
}

h1 {
    color: maroon;
    margin-left: 40px;
}';

?>