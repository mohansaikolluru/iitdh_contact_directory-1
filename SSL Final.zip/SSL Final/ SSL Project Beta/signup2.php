<?php
echo '<title>IIT Dharwad Contact Directory</title>';
require("signup.php");
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$tab1="details";
$username=$_POST["username"];
$password=$_POST["password"];
if($username!=""&&$password!="")
{
    $find="SELECT username FROM details WHERE username ='$username'";
        $temp=mysqli_query($conn, $find);
        $check = mysqli_fetch_assoc($temp);
        //echo $check["username"];
        if($check["username"]==$username)
        {
                echo "<script>
                alert('Username already taken! Kindly use a different username');
                window.location.href='signup1.php';
                </script>";
        }
        else 
        {
$add="INSERT INTO $tab1 (username,password) VALUES ('$username', '$password')"; 
mysqli_query($conn, $add);
mysqli_close($conn);
echo "<script>
                alert('You are signed up! Kindly login now');
                window.location.href='pro0.php';
                </script>";
    echo '<style>
body {
    background-color: linen;
}

h1 {
    color: maroon;
    margin-left: 40px;
}';
}
}   
else
{
    echo "<script>
                alert('No details entered!');
                window.location.href='signup1.php';
                </script>";
}
?>