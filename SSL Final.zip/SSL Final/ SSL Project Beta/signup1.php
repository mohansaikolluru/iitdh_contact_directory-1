<html>
<title>IIT Dharwad Contact Directory</title>
<body>

	<center>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
<form enctype="multipart/form-data" action="signup2.php" method="post">
	<font size="4"> 
	Username: <input type="text" name="username"> 
	<!--<br> -->&nbsp;
	Password: <input type="text" name="password">
	<!--<br> 
	Email: <input type="text" name="email"> 
	<br> 
	Number: <input type="text" name="numero">--> 
	<br>
	<br>
	<br>
	<input type="submit" style="font-size : 20px; width: 15%; height: 100px;"  value="Sign Up" name="submit">
	<br>
	<br>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</form>
<form enctype="multipart/form-data" action="pro0.php" method="POST">
<button type="submit" style="font-size : 15px; width: 7%; height: 25px;"class="btn"><i class="fa fa-home"></i> Home</button></form>
</center>
</body>

<style>
body {
    background-color: linen;
}

h1 {
    color: maroon;
    margin-left: 40px;
}
</style>
</html>
