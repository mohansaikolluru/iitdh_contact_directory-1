<?php
$servername = "localhost";
$username = "root";
$password = "password";
$create = "CREATE DATABASE rrecords";
$conn = mysqli_connect($servername, $username, $password);
mysqli_query($conn, $create);
/*if (mysqli_query($conn, $create)) {
    echo "Database created successfully with the name newDB";
}*/
mysqli_query($conn,"USE rrecords");
$table='CREATE TABLE pprofessor (name VARCHAR(120), department VARCHAR(120), email VARCHAR (120), numero VARCHAR(120), designation VARCHAR(120))';
mysqli_query($conn,$table);
/*if (mysqli_query($conn,$table))
echo "hi"; 
else echo "bye" ;*/
$dbname = "rrecords";
?>