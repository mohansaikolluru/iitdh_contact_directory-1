<?php
if ($_SERVER['HTTP_REFERER'] == 'http://localhost/pro0.1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/pro2.1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/pro3.1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/pro8.1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/pro9.1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/pro10.1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/pro4.1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/promod1.php') {
    echo ' <style>input {
    font-family: "Helvetica Neue", Helvetica, sans-serif;
    font-size: 12px;
    outline: none;}</style>';
    if(isset($_POST["submit"]))
    {
        require("signup.php");
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) 
            {
                 die("Connection failed: " . mysqli_connect_error());
            }
        $tab1="details";
        $username=$_POST["username"];
        $password=$_POST["password"];
        $find="SELECT password FROM details WHERE username ='$username'";
        $temp=mysqli_query($conn, $find);
        $check = mysqli_fetch_assoc($temp);
        if(($password==$check["password"])&&($username!=""&&$password!="")&&($username!="/^1[6,7,8,9][0,1,2,3][0,1,2,3][1,2,3][0-9]{4}$/"))
            {
                require("login.php");
                 $conn = mysqli_connect($servername, $username, $password, $dbname);
                if (!$conn) 
                    {
                        die("Connection failed: " . mysqli_connect_error());
                    }
                    echo '<div align=right>';
             echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
              echo '<form enctype="multipart/form-data" action="pro0.1.php" method="POST">';
    echo '<button type="submit"style="font-size : 15px; width: 10%; height: 25px;" class="btn"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</button>';
    echo '</form>';
                echo '<title>IIT Dharwad Contact Directory</title>';
                echo '<div class="container">
                <div class="vertical-center">';
                echo '<center>'; 
                echo '<img src="3.jpg" height="200" width="240">';
                echo '<head> <center> <strong> <font size="6"><font color="blue">Welcome to IIT Dharwad Contact Directory</font> </strong> </center> </head>';
                echo '<p>';
                echo '<form enctype="multipart/form-data" action="pro2.1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;" value="View All Records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<form enctype="multipart/form-data" action="pro3.1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;" value="Add to Records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                /*
                echo '<form enctype="multipart/form-data" action="pro5.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;" value="Delete my records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<br>';
                */
                echo '<form enctype="multipart/form-data" action="pro8.1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;"value="Search Records" />';      echo '</form>'; echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<form enctype="multipart/form-data" action="promod1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;"value="Modify your Records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
            echo '<br>';
          
                echo '</p>';
                echo '</center>';
                echo '<style>
                body {
                        background-color: linen;
                     }

                h1 {
                    color: maroon;
                    margin-left: 40px;
                }';
                echo '</div>
                </div>';
                echo '<style>
                .container { 
                  height: 200px;
                  position: relative;
                  border: 3px solid green; 
                }

                .vertical-center {
                  margin: 240;
                  position: absolute;
                  top: 25%;
                  -ms-transform: translateY(10%);
                  transform: translateY(-70%);
                }
                </style>';
            }

        else
            {
                echo "<script>
                alert('Login unsuccessful!');
                window.location.href='pro0.1.php';
                </script>";
            }

    }
    else 
    {
        require("signup.php");
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if (!$conn) 
            {
                 die("Connection failed: " . mysqli_connect_error());
            }
                    echo '<div align=right>';
             echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
              echo '<form enctype="multipart/form-data" action="pro0.1.php" method="POST">';
    echo '<button type="submit"style="font-size : 15px; width: 10%; height: 25px;" class="btn"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</button>';
    echo '</form>';
                echo '<title>IIT Dharwad Contact Directory</title>';
                echo '<div class="container">
                <div class="vertical-center">';
                echo '<center>'; 
                echo '<img src="3.jpg" height="200" width="240">';
                echo '<head> <center> <strong> <font size="6"><font color="blue">Welcome to IIT Dharwad Contact Directory</font> </strong> </center> </head>';
                echo '<p>';
                echo '<form enctype="multipart/form-data" action="pro2.1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;" value="View All Records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                
                echo '<form enctype="multipart/form-data" action="pro3.1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;" value="Add to Records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                /*
                echo '<form enctype="multipart/form-data" action="pro5.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;" value="Delete my records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<br>';
                */
                echo '<form enctype="multipart/form-data" action="pro8.1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;"value="Search Records" />';  echo '</form>'; echo '&nbsp &nbsp &nbsp &nbsp';
                echo '<form enctype="multipart/form-data" action="promod1.php" method="POST">';
                echo '<input type="submit" style="font-size : 20px; width: 25%; height: 100px;"value="Modify your Records" />';
                echo '</form>';
                echo '&nbsp &nbsp &nbsp &nbsp';
            echo '<br>';
                echo '</p>';
                echo '</center>';
                echo '<style>
                body {
                        background-color: linen;
                     }

                h1 {
                    color: maroon;
                    margin-left: 40px;
                }';
                echo '</div>
                </div>';
                echo '<style>
                .container { 
                  height: 200px;
                  position: relative;
                  border: 3px solid green; 
                }

                .vertical-center {
                  margin: 240;
                  position: absolute;
                  top: 25%;
                  -ms-transform: translateY(10%);
                  transform: translateY(-70%);
                }
                </style>';
            }
        }
            else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>