<?php
if ($_SERVER['HTTP_REFERER'] == 'http://localhost/pro1.php'||$_SERVER['HTTP_REFERER'] == 'http://localhost/pro6.php')
	{echo '
<html>
<title>IIT Dharwad Contact Directory</title>
<head>
	<script type="text/javascript">
	function confirmDelete()
	{
   		return confirm("Are you sure you want to delete this?");
	}
	</script>
</head>
<body>

	<center>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
<form enctype="multipart/form-data" action="pro6.php" method="post">
	<font size="4"> Name: <input type="text" name="name"> 
	<!--<br> -->&nbsp;
	<font size="4">Department: <!--<input  name="department" > --type="text"-->
	<select name="department">
  <option value="Director">Director</option>
	<option value="Deans">Deans</option>
	<option value="Registry Office">Registry Office</option>
	<option value="Mentoring Cell">Mentoring Cell</option>
	<option value="Administrative Staff">Administrative Staff</option>
	<option value="Academic Staff">Academic Staff</option>
	<option value="Library Staff">Library Staff</option>
  <option value="Computer Center">Computer Center</option>
  <option value="Infrastructure, Planning and Support">Infrastructure, Planning and Support</option>
  <option value="Computer Science Engineering">Computer Science Engineering</option>
  <option value="Electrical Engineering">Electrical Engineering</option>
  <option value="Mechanical Engineering">Mechanical Engineering</option>
  <option value="Mathematics">Mathematics</option>
  <option value="Physics">Physics</option>
  <option value="Chemistry">Chemistry</option>
  <option value="Biosciences and Bioengineering">Biosciences and Bioengineering</option>
  <option value="Humanities and Social Sciences">Humanities and Social Sciences</option>
  <option value="Junior Technical Superintendents">Junior Technical Superintendents</option>
  <option value="Teaching Assistants">Teaching Assistants</option>
  <option value="Physical Education">Physical Education</option>
  <option value="General Secretary Academic Affairs">General Secretary Academic Affairs</option>
  <option value="General Secretary Sports Affairs">General Secretary Sports Affairs</option>
  <option value="General Secretary Cultural Affairs">General Secretary Cultural Affairs</option>
  <option value="General Secretary Hostel Affairs">General Secretary Hostel Affairs</option>
 
</select>
	Email: <input type="text" name="email"> 
	<!--<br> -->
	Number: <input type="text" name="numero"> 
	<br>
	<br>
	<br>
	<input type="submit" style="font-size : 20px; width: 15%; height: 100px;"  value="Delete" onclick="return confirmDelete()"">
	<br>
	<br>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</form>
<form enctype="multipart/form-data" action="pro1.php" method="POST">
<button type="submit" style="font-size : 15px; width: 7%; height: 25px;"class="btn"><i class="fa fa-home"></i> Home</button></form>
</center>
</body>

<style>
body {
    background-color: linen;
}

h1 {
    color: maroon;
    margin-left: 40px;
}
</style>
</html>';
}
else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>