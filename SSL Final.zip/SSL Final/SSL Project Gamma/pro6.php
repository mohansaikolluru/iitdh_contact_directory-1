<?php
if ($_SERVER['HTTP_REFERER'] == 'http://localhost/pro5.php')
{
echo '<title>IIT Dharwad Contact Directory</title>';
echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
echo '<form enctype="multipart/form-data" action="pro1.php" method="POST">
 <button type="submit" style="font-size : 15px; width: 7%; height: 25px;"class="btn"><i class="fa fa-home"></i> Home</button>
</form>';
echo '<font size="4">';
echo '<br>';
require("login.php");
$conn = mysqli_connect($servername, $username, $password, $dbname);
$name = $_POST["name"];
$email = $_POST["email"];
$department = $_POST["department"];
$number = $_POST["numero"];
$phone=$number;
if($name!=""&&$email!=""&&$department!=""&&$number!="")
{
    if(preg_match("/^\+91-[7,8,9][0-9]{9}$/", $phone)||preg_match("/^\+91-0836[0-9]{6}$/", $phone)||preg_match("/^NA$/", $phone)) 
        {
            $find="SELECT * FROM professor WHERE name= '$name' AND department='$department' AND email='$email'AND numero='$number'";
            $temp=mysqli_query($conn, $find);
            $check = mysqli_fetch_assoc($temp);
            if($check["name"]!=$name&&$check["department"]!=$department&&$check["email"]!=$email&&$check["numero"]!=$number)
                {
                    echo "<script>
                    alert('Record not found! Kindly re-check your details');
                    window.location.href='pro5.php';
                    </script>";
        
                }
            else
                {
                        $query = "DELETE FROM professor WHERE name= '$name' AND department='$department' AND email='$email'AND numero='$number'";
                        mysqli_query($conn, $query);
                        $sql = "SELECT name,department,email,numero FROM professor";
                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) 
                            {
                                echo " <b>";
                                echo "Records";
                                echo " </b>"."<br>"."<br>";
                                while($row = mysqli_fetch_assoc($result)) 
                                    {
                                        echo "<b>"."Name:"."</b>" ."        ". $row["name"]."<br>". "<b>"."Department:"."</b>"."        ". $row["department"]."<br>". "<b>"."Email:"."</b>" ."      ". $row["email"]. "<br>". "<b>"."Number:"."</b>" ."        ". $row["numero"]. "<br>"."---------------------------------------------------------------"."<br>";
                                    }

                            }
                            else 
                                {
                                    echo "0 results";
                                }
                }
        }
    else 
        {
            echo "<script>
            alert('Invalid number!');
            window.location.href='pro5.php';
            </script>";
        }
}
else
    {
        echo "<script>
        alert('Record not found! Kindly re-check your details');
        window.location.href='pro5.php';
        </script>";
    }
mysqli_close($conn);
echo '<style>
body {
    background-color: linen;
}

h1 {
    color: maroon;
    margin-left: 40px;
}';
}
else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>