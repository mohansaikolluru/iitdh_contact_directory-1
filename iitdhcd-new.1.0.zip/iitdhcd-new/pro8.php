<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IIT Dharwad Contact Directory</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/1.jpg">
       <!-- <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">-->

    </head>
    <body>
       <style>
        .container-fluid {

  }
        .bg-1 { 
            width: 72%;
      background-color: #ffffff/*#1abc9c*/; /* Green */
      color: #071228;
      border-radius: 25px;
      padding-top: 0px;
      padding-bottom: 0px;
  }
        </style>
<p> 
        <form enctype="multipart/form-data" action="pro1.php" method="POST">
               <input type="submit" class="btn" value="Back" name="back" style="float: left; width: 6%; margin-left: 2%;margin-top: 1%;background-color: #b6fb37;color: #000000" >
                </form>
            </p>
<?php
if ($_SERVER['HTTP_REFERER'] == 'http://10.250.8.18/iitdhcd-new/pro1.php'||$_SERVER['HTTP_REFERER'] == 'http://10.250.8.18/iitdhcd-new/pro9.php'||$_SERVER['HTTP_REFERER'] == 'http://10.250.8.18/iitdhcd-new/pro10.php'||$_SERVER['HTTP_REFERER'] == 'http://10.250.8.18/iitdhcd-new/pro8.5.php')
	{echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
echo'<div class="top-content">
            <div class="inner-bg">
                <img src="1.jpg" class="img-responsive img-circle
                    margin" style="display:inline;border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;" width="150" height="150">
                <div class="container">
                    <div class="row">
                        
                        <div class="container-fluid bg-1 text-center" style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37; background-color: #ffffff">
                            <h1>
                                <strong>IIT Dharwad Contact Directory</strong> 
                            </h1>
                        </div>
                    </div>';
echo'<div class="row" >
                        <div class="col-sm-6 col-sm-offset-3 form-box" >
                            <div class="form-bottom"style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;">
                          <form enctype="multipart/form-data" action="pro9.php" method="post">
	<div class="form-group">
                               Department<br>
                              <label class="sr-only" for="form-username">Department</label>
                                <select name="department">
  <option value="Director">Director</option>
	<option value="Deans">Deans</option>
	<option value="Registry Office">Registry Office</option>
	<option value="Mentoring Cell">Mentoring Cell</option>
	<option value="Administrative Staff">Administrative Staff</option>
	<option value="Academic Staff">Academic Staff</option>
	<option value="Library Staff">Library Staff</option>
  <option value="Computer Center">Computer Center</option>
  <option value="Infrastructure, Planning and Support">Infrastructure, Planning and Support</option>
  <option value="Computer Science Engineering">Computer Science Engineering</option>
  <option value="Electrical Engineering">Electrical Engineering</option>
  <option value="Mechanical Engineering">Mechanical Engineering</option>
  <option value="Mathematics">Mathematics</option>
  <option value="Physics">Physics</option>
  <option value="Chemistry">Chemistry</option>
  <option value="Biosciences and Bioengineering">Biosciences and Bioengineering</option>
  <option value="Humanities and Social Sciences">Humanities and Social Sciences</option>
  <option value="Junior Technical Superintendents">Junior Technical Superintendents</option>
  <option value="Teaching Assistants">Teaching Assistants</option>
  <option value="Physical Education">Physical Education</option>
  <option value="General Secretary Academic Affairs">General Secretary Academic Affairs</option>
  <option value="General Secretary Sports Affairs">General Secretary Sports Affairs</option>
  <option value="General Secretary Cultural Affairs">General Secretary Cultural Affairs</option>
  <option value="General Secretary Hostel Affairs">General Secretary Hostel Affairs</option>

</select>
<button type="submit" class="btn" name="submit" style="background-color: #b6fb37;color: #000000">Search by Department</button>
                              <div class="description" style="color: #0c121f">
                            </div>
                            </div>
</form>';
echo'<form enctype="multipart/form-data" action="pro10.php" method="post">
                            <div class="form-group">
                                Name<br>
                                <input type="texty" class="form-username form-control" name="name"
    border: 1px solid #a8c9e4;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #e6f2f9;">
                              </div>
                              <button type="submit" class="btn" name="submit" style="background-color: #b6fb37;color: #000000">Search by Search by Name</button>
                              <div class="description" style="color: #0c121f">
                            </div>
                            </form>'
                            ;
                            echo'<form enctype="multipart/form-data" action="pro8.5.php" method="post">
                            <div class="form-group">
                                Email<br>
                                <input type="texty" class="form-username form-control" name="email" style="
    border: 1px solid #a8c9e4;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #e6f2f9">
                              </div>
  <button type="submit" class="btn" name="submit" style="background-color: #b6fb37; color: #000000">Search by Email </button>
                              <div class="description" style="color: #0c121f">
                            </div>
                            </form>';
}
else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>

</body>
 <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
</html>

