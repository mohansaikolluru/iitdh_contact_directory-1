<?php
require("signup.php");
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$tab1="details";
$add="INSERT INTO $tab1 (username,password) VALUES ('$username', '$password')"; 
mysqli_query($conn, $add);
mysqli_close($conn);
?>