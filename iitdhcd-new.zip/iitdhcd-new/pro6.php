<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IIT Dharwad Contact Directory</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/1.jpg">
       <!-- <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">-->
    </head>

    <body>
        <style>
        .container-fluid {

  }
        .bg-1 { 
            width: 72%;
      background-color: #ffffff/*#1abc9c*/; /* Green */
      color: #071228;
      border-radius: 25px;
      padding-top: 0px;
      padding-bottom: 0px;

  }
        </style>

<?php
if ($_SERVER['HTTP_REFERER'] == 'http://10.250.8.18/iitdhcd-new/pro5.php')
{
echo '<form enctype="multipart/form-data" action="pro1.php" method="POST">
               <input type="submit" class="btn" value="Back" name="back" style="float: left; width: 6%; margin-left: 2%;margin-top: 1%;background-color: #b6fb37;color: #000000" >
                </form>';
                echo '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">';
echo'<div class="top-content">
            <div class="inner-bg">
                <img src="1.jpg" class="img-responsive img-circle
                    margin" style="display:inline;border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;" width="150" height="150">
                <div class="container">
                    <div class="row">
                        
                        <div class="container-fluid bg-1 text-center" style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37; background-color: #ffffff">
                            <h1>
                                <strong>IIT Dharwad Contact Directory</strong> 
                            </h1>
                        </div>
                    </div>
                    <br>
                    <br>';
require("login.php");
$conn = mysqli_connect($servername, $username, $password, $dbname);
$name = $_POST["name"];
$email = $_POST["email"];
$department = $_POST["department"];
$number = $_POST["numero"];
$phone=$number;
if($email!="")
{
    /*if(preg_match("/^\+91-[7,8,9][0-9]{9}$/", $phone)||preg_match("/^\+91-0836[0-9]{6}$/", $phone)||preg_match("/^NA$/", $phone)) */
        {
            $find="SELECT * FROM professor WHERE email='$email'";
            $temp=mysqli_query($conn, $find);
            $check = mysqli_fetch_assoc($temp);
            if($check["email"]!=$email)
                {
                    echo "<script>
                    alert('Record not found! Kindly re-check your details');
                    window.location.href='pro5.php';
                    </script>";
        
                }
            else
                {
                        $query = "DELETE FROM professor WHERE email='$email'";
                        mysqli_query($conn, $query);
                        $sql = "SELECT name,department,email,numero,designation FROM professor";
                        $result = mysqli_query($conn, $sql);

                        if (mysqli_num_rows($result) > 0) 
                            {
                                echo'<div class="container" >
    <table class="table">
    <thead>
      <tr class="info">
        <th>Name</th>
        <th>Department</th>
        <th>Designation</th>
        <th>Email</th>
        <th>Number</th>
      </tr>
    </thead>
    <tbody>';
    
   while($row = mysqli_fetch_assoc($result)) {
    echo'<tr class="warning">';
        echo'<td style="text-align:left"><strong>'.$row["name"].'</td>
        <td style="text-align:left"><strong>'.$row["department"].'</td>
        <td style="text-align:left"><strong>'.$row["designation"].'</td>
        <td style="text-align:left"><strong>'.$row["email"].'</td>
       <td style="text-align:left"><strong>'.$row["numero"].'</td>
      </tr>';
       /* echo "<b>"."Name:"."</b>" ."        ". $row["name"]."<br>". "<b>"."Department:"."</b>"."        ". $row["department"]."<br>". "<b>"."Designation:"."</b>"."      ". $row["designation"]."<br>". "<b>"."Email:"."</b>" ."        ". $row["email"]. "<br>". "<b>"."Number:"."</b>" ."        ". $row["numero"]. "<br>"."------------------------------------------------------------------------"."<br>";*/
    }echo'
    </tbody>
  </table>
</div>';
     }
                            else 
                                {
                                    echo "<script>
                alert('No records available!');
                window.location.href='pro5.php';
                </script>";
                                }
                }
        }
    /*else 
        {
            echo "<script>
            alert('Invalid number!');
            window.location.href='pro5.php';
            </script>";
        }*/
}
else
    {
        echo "<script>
        alert('Record not found! Kindly re-check your details');
        window.location.href='pro5.php';
        </script>";
    }
mysqli_close($conn);

}
else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
?>
</body>
 <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
</html>