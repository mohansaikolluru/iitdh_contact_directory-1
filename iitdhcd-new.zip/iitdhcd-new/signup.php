<?php//code for creating database to store login credentials of users
$servername = "localhost";
$username = "root";
$password = "password";
$create = "CREATE DATABASE signup";
$conn = mysqli_connect($servername, $username, $password);
mysqli_query($conn, $create);
/*if (mysqli_query($conn, $create)) {
    echo "Database created successfully with the name newDB";
}*/
mysqli_query($conn,"USE signup");
$table='CREATE TABLE details (username VARCHAR(120), password VARCHAR(120))';
mysqli_query($conn,$table);
/*if (mysqli_query($conn,$table))
echo "hi"; 
else echo "bye" ;*/
$dbname = "signup";
?>