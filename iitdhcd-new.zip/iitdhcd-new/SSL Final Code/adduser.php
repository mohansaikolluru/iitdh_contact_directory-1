<?php
require("login.php");
$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT name,department,email,numero,designation FROM professor";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
 	
    
   while($row = mysqli_fetch_assoc($result)) {
   	$temp=$row["email"];
    echo $temp; echo '<br>';
   	require("signup.php");
   	$connn = mysqli_connect($servername, $username, $password, $dbname);
   	$tab1="details";
	$add="INSERT INTO $tab1 (username,password) VALUES ('$temp','$temp')"; 
	if(mysqli_query($connn, $add))
  {
    echo "hi";
  }
	mysqli_close($connn);
     
    }
}
mysqli_close($conn);

?>


