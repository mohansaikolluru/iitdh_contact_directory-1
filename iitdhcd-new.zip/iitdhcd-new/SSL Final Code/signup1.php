<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IIT Dharwad Contact Directory</title>

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/1.jpg">
       <!-- <link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">-->

    </head>

    <body>
        <style>
        .container-fluid {

  }
        .bg-1 { 
            width: 72%;
      background-color: #ffffff/*#1abc9c*/; /* Green */
      color: #071228;
      border-radius: 25px;
      padding-top: 0px;
      padding-bottom: 0px;

  }
        </style>
<?php
if ($_SERVER['HTTP_REFERER'] == 'http://192.168.43.144/iitdhcd-home/pro1.php'||$_SERVER['HTTP_REFERER'] == 'http://192.168.43.144/iitdhcd-home/signup2.php')
	{echo '<p> 
        <form enctype="multipart/form-data" action="pro1.php" method="POST">
               <input type="submit" class="btn" value="Back" name="back" style="float: left; width: 6%; margin-left: 2%;margin-top: 1%;background-color: #b6fb37;color: #000000" >
                </form>
            </p>
        <!-- Top content -->
        <div class="top-content">
            <div class="inner-bg">
                <img src="1.jpg" class="img-responsive img-circle
                    margin" style="display:inline;border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;" width="150" height="150">
                <div class="container">
                    <div class="row">
                        
                        <div class="container-fluid bg-1 text-center" style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37; background-color: #ffffff">
                            <h1>
                                <strong>IIT Dharwad Contact Directory</strong> 
                            </h1>
                        </div>
                    </div>
                    <div class="row" >
                        <div class="col-sm-6 col-sm-offset-3 form-box" >
                          <div class="form-top"style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;">
                            <div class="form-top-left">
                                <h3>Add User </h3>
                                
                            </div>
                            <div class="form-top-right">
                              <i class="fa fa-user"></i>
                            </div>
                            </div>
                            <div class="form-bottom"style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;">
                          <form enctype="multipart/form-data" action="signup2.php" method="POST">
                            <div class="form-group">
                                
                              <label class="sr-only" for="form-username">Username</label>
                                <input type="text" name="username" placeholder="Username" class="form-username form-control" id="username" style="
    border: 1px solid #a8c9e4;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #e6f2f9;">
                              </div>
                              <div class="form-group">
                                <label class="sr-only" for="form-password">Password</label>
                                <input type="password" name="password" placeholder="Password" class="form-password form-control" id="password" style="
    border: 1px solid #a8c9e4;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #e6f2f9;">
                              </div>
                              <button type="submit" class="btn" name="submit" style="background-color: #b6fb37;color: #000000">Add User</button>
                              <div class="description" style="color: #0c121f">
                            </div>
                          </form>
                        </div>
                        </div>
                    </div>
                      </div>
            </div>
        </div>';


}
else 
{
     echo "<script>
                alert('Access denied!');
                window.location.href='pro0.php';
                </script>";
}
        
?>
<!-- Javascript -->
        <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>
        
        <!--[if lt IE 10]>
            <script src="assets/js/placeholder.js"></script>
        <![endif]-->

    </body>

</html> 
