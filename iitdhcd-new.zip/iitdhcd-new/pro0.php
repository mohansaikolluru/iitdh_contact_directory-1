<!DOCTYPE html><!-- home page-->
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>IIT Dharwad Contact Directory</title><!-- page title-->

        <!-- CSS -->
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">
        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/form-elements.css">
        <link rel="stylesheet" href="assets/css/style.css">

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

        <!-- Favicon and touch icons -->
        <link rel="shortcut icon" href="assets/ico/1.jpg"><!-- address bar shortcut icon-->
        <!--<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
        <link rel="apple-touch-icon-precomposed" href="assets/ico/apple-touch-icon-57-precomposed.png">-->

    </head>

    <body>
        <style>
        .container-fluid {

  }
        .bg-1 { 
            width: 72%;
      background-color: #ffffff/*#1abc9c*/; /* Green */
      color: #071228;
      border-radius: 25px;
      padding-top: 0px;
      padding-bottom: 0px;

  }
      .navbar {
      border: 0;
      border-radius: 0;
      margin-bottom: 0;
      font-size: 13px;
      letter-spacing: 3px;
      background-color: #b6fb37;
      color:#b6fb37;
  }
  .navbar-nav  li a:hover {
      color: #ffffff;/*#1abc9c !important;*/
  }
  .bg-4 { 
      background-color: #2f2f2f; /* Black Gray */
      color: #ffffff;
      word-spacing: 0px;
  }
  .footer {
  position: absolute;
  right: 0;
  bottom: 0;
  left: 0;
  padding: 1rem;
  background-color: #2f2f2f;
  text-align: center;
}
        </style>
        <nav class="navbar navbar-default">
            <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="pro0.1.php"><b>LOGIN</b></a></li><!-- login link-->
        <!--<li><a href="pro0.0.php"><b>ADMIN LOGIN</b></a></li>-->
        <!--<li><a href="#">WHERE</a></li>-->
      </ul>
    </div>
</nav>
        <div class="top-content"><!-- code for the header title and image-->
            <div class="inner-bg">
                <img src="1.jpg" class="img-responsive img-circle
                    margin" style="display:inline;border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37;" width="150" height="150">
                <div class="container">
                    <div class="row">
                        
                        <div class="container-fluid bg-1 text-center" style="
    border: 1px /*solid #a8c9e4*/;
    box-shadow: inset 0 1.5px 3px rgba(190, 190, 190, .4), 0 0 0 5px #b6fb37; background-color: #ffffff">
                            <h1>
                                <strong>IIT Dharwad Contact Directory</strong> 
                            </h1>
                        </div>
                    </div>






    <div class="row " style="margin-top: 5%" ><!-- button for view all records-->
            <form enctype="multipart/form-data" action="pro2.php" method="POST">
                <input type="submit" class="btn" value="View All Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" name="index" >
                </form>
                <br>
    <form enctype="multipart/form-data" action="pro8.0.php" method="POST"><!-- button for search records-->
                <input type="submit" class="btn" value="Search Records" style="float: center; width: 20%;background-color: #b6fb37;color: #000000" name="index" >
                </form>
                <br>
                <!--
                <form enctype="multipart/form-data" action="pro0.1.php" method="POST" name="index">
                <input type="submit" class="btn" value="Login as User" style="float: center; width: 20%;background-color: #f0b477;color: #ffffff" >
                </form>
                <br>
                <form enctype="multipart/form-data" action="pro0.0.php" method="POST" name="index">
                <input type="submit" class="btn" value="Login as Admin" style="float: center; width: 20%;background-color: #f0b477;color: #ffffff" >
                </form>
            -->
            </div><!-- Background graphics-->
            <script src="assets/js/jquery-1.11.1.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.backstretch.min.js"></script>
        <script src="assets/js/scripts.js"></script>


        <div class="footer"><!-- Footer for web designer names and copyright -->
  <p><span class="glyphicon glyphicon-copyright-mark"> 2018 IIT Dharwad</a></p> 
    <p>Designed by Sai Anuroop Kesanapalli & Mohan Sai Kolluru</p>
</div>
         </body>

</html> 
    <!-- Begin Page Content -->
    <!--<div id="container">-->

    <!--<form enctype="multipart/form-data" action="signup1.php" method="POST">
                <input type="submit" value="Sign Up" />
                </form></center>
                <br>
            <form enctype="multipart/form-data" action="pro1.php" method="POST">-->
            <!--<label for="username">Username:</label>
            <input type="text" id="username" name="username">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password">
            <div id="lower">
                <input type="checkbox"><label class="check" for="checkbox">Keep me logged in</label>-->
                